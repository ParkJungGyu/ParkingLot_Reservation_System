package com.project.afinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CancelAdapter extends BaseAdapter {
    serviceApi serviceApi = RetrofitClient.getClient("http://ec2-43-200-49-74.ap-northeast-2.compute.amazonaws.com:3000").create(serviceApi.class);
    Context context=null;
    LayoutInflater layoutInflater=null;
    List<parkiu> parkius=null;
    //Park_User_Data data;
    ArrayList<Park_User_Data> pud;

    public CancelAdapter(Context context, List<parkiu> parkius, ArrayList<Park_User_Data> pud){
        this.context=context;
        this.parkius=parkius;
        this.layoutInflater=LayoutInflater.from(context);
        this.pud=pud;
    }

    @Override
    public int getCount() {
        return parkius.size();
    }

    @Override
    public parkiu getItem(int position) {
        return parkius.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View cview, ViewGroup cgroup) {
        View view=layoutInflater.inflate(R.layout.parkinglot_info,null);

        TextView tx1=view.findViewById(R.id.textView1);
        TextView tx2=view.findViewById(R.id.textView2);
        Button bt1=view.findViewById(R.id.button1);


        tx1.setText(parkius.get(position).parkname);
        tx2.setText(parkius.get(position).p_number+"\n"+parkius.get(position).getRdate());
        Park_User_Data data=pud.get(position);
        bt1.setText("취소");
            bt1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    serviceApi.delete_parking(data).enqueue(new Callback<code_message_Response>() {
                        @Override
                        public void onResponse(Call<code_message_Response> call, Response<code_message_Response> response) {
                            if(response.isSuccessful()){
                                bt1.setEnabled(false);
                                bt1.setText("취소완료");
                            }else{

                            }
                        }

                        @Override
                        public void onFailure(Call<code_message_Response> call, Throwable t) {

                        }
                    });
                }});

        return view;
    }
}
