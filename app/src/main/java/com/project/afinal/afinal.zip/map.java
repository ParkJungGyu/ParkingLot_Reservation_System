package com.project.afinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraPosition;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.UiSettings;
import com.naver.maps.map.overlay.InfoWindow;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.Overlay;
import com.naver.maps.map.util.FusedLocationSource;
import com.naver.maps.map.util.MarkerIcons;

import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class map extends AppCompatActivity implements OnMapReadyCallback ,Overlay.OnClickListener{
    serviceApi serviceApi = RetrofitClient.getClient("http://ec2-43-200-49-74.ap-northeast-2.compute.amazonaws.com:3000").create(serviceApi.class);
    private long backKeyPressedTime = 0;
    private TextView tx;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1000;
    OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(1, TimeUnit.MINUTES)
            .readTimeout(10,TimeUnit.SECONDS)
            .writeTimeout(10,TimeUnit.SECONDS)
            .build();

    private FusedLocationSource locationSource;
    private NaverMap naverMap;
    private Button regif,buf,logout;
    private EditText et;
    private List<parking> lm;
    private InfoWindow mInfoWindow;
    private String id;
    private one_park_space ops;
    private Toast toast;
    private Marker searchMark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        locationSource =
                new FusedLocationSource(this, LOCATION_PERMISSION_REQUEST_CODE);


        regif=findViewById(R.id.info);
        buf=findViewById(R.id.but);
        et=findViewById(R.id.address);
        logout=findViewById(R.id.logout);


        FragmentManager fm = getSupportFragmentManager();
        MapFragment mapFragment = (MapFragment)fm.findFragmentById(R.id.navermap);
        if (mapFragment == null) {
            mapFragment = MapFragment.newInstance();
            fm.beginTransaction().add(R.id.navermap, mapFragment).commit();
        }
        mapFragment.getMapAsync(this );

        Intent intent=getIntent();
        id=intent.getStringExtra("id");

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                toast=Toast.makeText(map.this,"이용해 주셔서 감사합니다.",Toast.LENGTH_SHORT);
                toast.show();
            }
        });

        regif.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),Resinformation.class);
                intent.putExtra("id",id);
                //intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);

            }
        });
        buf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                Gson gson = new GsonBuilder().setLenient().create();

                Retrofit retrofitnaver = new Retrofit.Builder()
                        .baseUrl("https://naveropenapi.apigw.ntruss.com/")
                        .addConverterFactory(GsonConverterFactory.create(gson))
                        .client(client)
                        .build();

                retrofitnaver.create(RetrofitAddress.class).searchAddress(et.getText().toString()).enqueue(new Callback<AddressData>() {
                    @Override
                    public void onResponse(Call<com.project.afinal.AddressData> call, Response<com.project.afinal.AddressData> response) {
                        try{

                            String point = response.body().toString();
                            String x = point.split("\n")[0];
                            String y = point.split("\n")[1];
                            Log.e("res",response.body().toString());


                        CameraPosition cameraPosition = new CameraPosition(
                                new LatLng(Double.parseDouble(y), Double.parseDouble(x)),  // 위치 지정
                                15                          // 줌 레벨
                        );
                            naverMap.setCameraPosition(cameraPosition);
                            if(searchMark!=null)
                            {
                                searchMark.setMap(null);
                            }
                            searchMark=new Marker();
                            searchMark.setIcon(MarkerIcons.BLACK);
                            searchMark.setIconTintColor(Color.RED);
                            searchMark.setPosition(new LatLng(Double.parseDouble(y), Double.parseDouble(x)));
                            searchMark.setOnClickListener(new Overlay.OnClickListener() {
                                @Override
                                public boolean onClick(@NonNull Overlay overlay) {
                                    String url = "nmap://navigation?dlat="+y+"&dlng="+x+"&dname="+et.getText().toString()+"&appname=com.example.myapp";

                                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                                    try {
                                        startActivity(intent);
                                    } catch (ActivityNotFoundException e) {
                                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.nhn.android.nmap")));
                                    }
                                    return false;
                                }
                            });
                            searchMark.setMap(naverMap);

                       }catch (Exception e){
                            Toast.makeText(map.this, "정확한 주소를 입력하세요.", Toast.LENGTH_SHORT).show();

                        }
                    }

                    @Override
                    public void onFailure(Call<AddressData> call, Throwable t) {

                    }
                });

            }
        });

    }
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (locationSource.onRequestPermissionsResult(
                requestCode, permissions, grantResults)) {
            return;
        }
        super.onRequestPermissionsResult(
                requestCode, permissions, grantResults);
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {


        this.naverMap=naverMap;
        UiSettings uiSettings = naverMap.getUiSettings();
        uiSettings.setLocationButtonEnabled(true);

        mInfoWindow = new InfoWindow();

        naverMap.setLocationSource(locationSource);
        serviceApi.parkinfoget(new LoginData("aa","22")).enqueue(new Callback<ParkInfoData>() {

            @Override
            public void onResponse(Call<ParkInfoData> call, Response<ParkInfoData> response) {

                if(response.isSuccessful()){
                    ParkInfoData ls=response.body();
                    lm=ls.getparkinfo();
                    Log.e("1 : ",Integer.toString(lm.size()));
                    if(lm!=null){
                        Log.e("Marker : ","complete");
                        for(int i=0;i<lm.size();i++){
                            Marker marker = new Marker();
                            marker.setPosition(new LatLng(Double.parseDouble(lm.get(i).getParky()), Double.parseDouble(lm.get(i).getParkx())));
                            marker.setMap(naverMap);
                            marker.setCaptionText(lm.get(i).getParkname());
                            marker.setOnClickListener(map.this);
                        }

                    }

                }
                else{
                    Log.e("2 : ",Integer.toString(response.code()));
                }
            }
            @Override
            public void onFailure(Call<ParkInfoData> call, Throwable t) {
                t.printStackTrace();

            }
        });


    }
    public boolean onClick(Overlay overlay){
        if (overlay instanceof Marker) {
            Marker marker = (Marker) overlay;
            Log.e("onclick","first");
            Park_User_Data data=new Park_User_Data(id,marker.getCaptionText());


            if (marker.getInfoWindow() != null) {
                mInfoWindow.close();
            }
            else {
                serviceApi.get_space(data).enqueue(new Callback<one_park_space>() {

                    @Override
                    public void onResponse(Call<one_park_space> call, Response<one_park_space> response) {

                        if(response.isSuccessful()){
                            ops=response.body();
                            mInfoWindow.setAdapter(new InfoWindow.DefaultViewAdapter(map.this) {
                                @NonNull
                                @Override
                                protected View getContentView(@NonNull InfoWindow infoWindow) {

                                    Marker marker = infoWindow.getMarker();
                                    View view = View.inflate(map.this, R.layout.info_view, null);
                                    ((TextView) view.findViewById(R.id.title)).setText(marker.getCaptionText());
                                    ((TextView) view.findViewById(R.id.details)).setText(" 빈 주차 공간 : "+ops.getParkempty());
                                    Log.e("Si : ","third");


                                    return view;
                                }
                            });
                            Log.e("ops : " ,"second");

                        }
                        else{

                        }
                    }
                    @Override
                    public void onFailure(Call<one_park_space> call, Throwable t) {
                        t.printStackTrace();

                    }
                });

                mInfoWindow.open(marker);
                marker.getInfoWindow().setOnClickListener(new Overlay.OnClickListener() {
                    @Override
                    public boolean onClick(@NonNull Overlay overlay) {
                        data.setParkempty(ops.getParkempty());
                        data.setParkspace(ops.getParkspace());
                        Intent intent=new Intent(getApplicationContext(),ParkinglotRes.class);
                        intent.putExtra("data",data);
                        startActivity(intent);
                        return false;
                    }
                });
            }
            return true;
        }
        return false;
    }
    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() > backKeyPressedTime + 2500) {
            backKeyPressedTime = System.currentTimeMillis();
            toast=Toast.makeText(this, "뒤로 가기 버튼을 한 번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        if (System.currentTimeMillis() <= backKeyPressedTime + 2500) {
            toast.cancel();
            toast=Toast.makeText(this,"이용해 주셔서 감사합니다.",Toast.LENGTH_SHORT);
            finishAffinity();
            toast.show();

        }
    }

}