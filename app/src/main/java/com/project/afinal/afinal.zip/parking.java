package com.project.afinal;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class parking {

    @SerializedName("parkname")
    @Expose
    private String parkname;
    @SerializedName("parkx")
    @Expose
    private String parkx;
    @SerializedName("parky")
    @Expose
    private String parky;
    @SerializedName("parkempty")
    @Expose
    private String parkempty;
    @SerializedName("parkspace")
    @Expose
    private String parkspace;

    public String getParkname() {
        return parkname;
    }

    public void setParkname(String parkname) {
        this.parkname = parkname;
    }

    public String getParkx() {
        return parkx;
    }

    public void setParkx(String parkx) {
        this.parkx = parkx;
    }

    public String getParky() {
        return parky;
    }

    public void setParky(String parky) {
        this.parky = parky;
    }

    public String getParkempty() {
        return parkempty;
    }

    public void setParkempty(String parkempty) {
        this.parkempty = parkempty;
    }

    public String getParkspace() {
        return parkspace;
    }

    public void setParkspace(String parkspace) {
        this.parkspace = parkspace;
    }

}
