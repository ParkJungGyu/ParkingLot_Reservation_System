package com.project.afinal;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface serviceApi {
    @POST("/user/login")
    Call<code_message_Response> userLogin(@Body LoginData data);

    @POST("/user/join")
    Call<code_message_Response> userJoin(@Body JoinData data);

    @POST("/user/parkinfo")
    Call<ParkInfoData> parkinfoget(@Body LoginData data);

    @POST("/user/one_park_space")
    Call<one_park_space> get_space(@Body Park_User_Data data);

    @POST("/user/parkinglotspace")
    Call<parkls_List> parkinglotspace(@Body Park_User_Data data);

    @POST("/user/save_parkinfo")
    Call<code_message_Response> save_parking(@Body Park_User_Data data);

    @POST("/user/delete_parkinfo")
    Call<code_message_Response> delete_parking(@Body Park_User_Data data);

    @POST("/user/parkinfo_user")
    Call<parkiu_list> parkinfo_user(@Body Park_User_Data data);

}