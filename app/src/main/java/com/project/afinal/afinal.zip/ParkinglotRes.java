package com.project.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ParkinglotRes extends AppCompatActivity {
    serviceApi serviceApi = RetrofitClient.getClient("http://ec2-43-200-49-74.ap-northeast-2.compute.amazonaws.com:3000").create(serviceApi.class);
    Park_User_Data park_user_data;
    ListView lv;
    List<parkls> pls;
    ArrayList<Park_User_Data> pud=new ArrayList<Park_User_Data>();
    TextView tx;
    ResAdapter resAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent=getIntent();
        park_user_data=(Park_User_Data) intent.getSerializableExtra("data");


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parkinglot_res);
        lv=findViewById(R.id.parking_list);
        tx=findViewById(R.id.parkname);
        tx.setText(park_user_data.getParkName()+"주차장 정보");


        serviceApi.parkinglotspace(park_user_data).enqueue(new Callback<parkls_List>() {
            @Override
            public void onResponse(Call<parkls_List> call, Response<parkls_List> response) {
                if(response.isSuccessful()){
                    parkls_List pp=response.body();
                    pls=pp.getparkls();
                    Log.e("pls : ","f");
                    Log.e("pls : ",pls.get(0).getP_number());

                    for(int i=0;i<pls.size();i++){
                        Park_User_Data pd=new Park_User_Data(park_user_data.getid(),park_user_data.getParkName());
                        pd.setP_number(pls.get(i).p_number);
                        pud.add(pd);
                        Log.e("is_park."+i+" ",pud.get(i).getP_number());
                    }

                    resAdapter =new ResAdapter(ParkinglotRes.this,pls,pud);
                    lv.setAdapter(resAdapter);

                }else{
                    Log.e("fail : ",park_user_data.getid());

                }

            }

            @Override
            public void onFailure(Call<parkls_List> call, Throwable t) {

            }
        });


        Log.e("pls : ","s");


        //Log.e("pls : ",pls.get(0).getP_number());




    }
    public void getParkSpace(Park_User_Data data){

    }

}