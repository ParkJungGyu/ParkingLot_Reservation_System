package com.project.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private long backKeyPressedTime = 0;
    private Button login;
    private TextView reg;
    private EditText etid,etpw;
    private String id, pw;
    private Toast toast;
    serviceApi service = RetrofitClient.getClient("http://ec2-43-200-49-74.ap-northeast-2.compute.amazonaws.com:3000").create(serviceApi.class);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login=findViewById(R.id.mainlogin);
        reg=findViewById(R.id.mainreg);

        etpw=findViewById(R.id.mainpw);
        etid=findViewById(R.id.mainid);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id=etid.getText().toString();
                pw=etpw.getText().toString();
                service.userLogin(new LoginData(id,pw)).enqueue(new Callback<code_message_Response>() {
                    @Override
                    public void onResponse(Call<code_message_Response> call, Response<code_message_Response> response) {

                        if(response.isSuccessful()){
                            code_message_Response result = response.body();
                            if(Integer.parseInt(result.getCode())==200){
                                Toast.makeText(MainActivity.this, id+"님 환영합니다.", Toast.LENGTH_SHORT).show();
                                Intent intent=new Intent(getApplicationContext(),map.class);
                                intent.putExtra("id",id);
                                startActivity(intent);
                            }
                            else if(Integer.parseInt(result.getCode())==205){
                                Toast.makeText(MainActivity.this, "아이디가 존재하지 않습니다.", Toast.LENGTH_SHORT).show();
                            }
                            else if(Integer.parseInt(result.getCode())==204){
                                Toast.makeText(MainActivity.this, "패스워드가 틀렸습니다.", Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(MainActivity.this, "정보를 입력해주세요", Toast.LENGTH_SHORT).show();
                            }
                            Log.e("res",response.body().getMessage());
                        }




                    }

                    @Override
                    public void onFailure(Call<code_message_Response> call, Throwable t) {
                        Toast.makeText(MainActivity.this, "로그인 에러 발생", Toast.LENGTH_SHORT).show();
                        Log.e("로그인 에러 발생", t.getMessage());
                        t.printStackTrace(); // 에러 발생시 에러 발생 원인 단계별로 출력해줌

                    }
                });


            }
        });

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),UserReg.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
            }
        });


    }

    @Override
    public void onBackPressed() {
        if (System.currentTimeMillis() > backKeyPressedTime + 2500) {
            backKeyPressedTime = System.currentTimeMillis();
            toast=Toast.makeText(this, "뒤로 가기 버튼을 한 번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT);
            toast.show();
            return;
        }
        if (System.currentTimeMillis() <= backKeyPressedTime + 2500) {
            toast.cancel();
            toast=Toast.makeText(this,"이용해 주셔서 감사합니다.",Toast.LENGTH_SHORT);
            finishAffinity();
            toast.show();

        }
    }
}